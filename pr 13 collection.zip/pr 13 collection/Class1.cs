﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_13_collection
{
    internal class Class1
    {
        public class Student
        {
            private string name;
            private string surname;
            private int bookname = 0;

            public Student(string name, string surname, int bookname)
            {
                this.name = name;
                this.surname = surname;
                this.bookname = bookname;
            }
            public string Get_name () { return name; }
            public string Get_surname () {  return surname; }
            public int Get_bookname () {  return bookname; }
        }
        
    }
}
